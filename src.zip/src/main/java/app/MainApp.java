package app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) {
        try {
            URL fxmlUrl = getClass().getResource("/view/login-view.fxml");
            if (fxmlUrl == null) {
                throw new RuntimeException("Không tìm thấy /view/login-view.fxml");
            }

            Parent root = FXMLLoader.load(fxmlUrl);
            Scene scene = new Scene(root, 420, 360);

            URL cssUrl = getClass().getResource("/css/style.css");
            if (cssUrl != null) {
                scene.getStylesheets().add(cssUrl.toExternalForm());
            } else {
                System.out.println("Không tìm thấy /css/style.css");
            }

            stage.setTitle("FleetCare - Đăng nhập");
            stage.setMinWidth(420);
            stage.setMinHeight(360);
            stage.setScene(scene);
            stage.centerOnScreen();
            stage.show();
        } catch (Exception e) {
            System.out.println("Lỗi khởi động ứng dụng");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
